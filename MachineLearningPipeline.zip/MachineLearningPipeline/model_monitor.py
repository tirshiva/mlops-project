import streamlit as st
import pandas as pd
import numpy as np
import os
import json
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta

class ModelMonitor:
    def render(self):
        st.header("Model Monitoring")
        
        # Check if models are deployed
        deployed_models = self._load_deployed_models()
        
        if not deployed_models:
            st.info("No deployed models found. Please deploy a model first.")
            return
        
        # Select model to monitor
        selected_model = st.selectbox(
            "Select Model to Monitor",
            options=list(deployed_models.keys())
        )
        
        # Get model details
        model_info = deployed_models[selected_model]
        
        # Display model information
        st.subheader("Model Information")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.write(f"**Name:** {model_info.get('name', 'N/A')}")
            st.write(f"**Version:** {model_info.get('version', 'N/A')}")
            st.write(f"**Model Type:** {model_info.get('model_type', 'N/A')}")
        
        with col2:
            st.write(f"**Created At:** {model_info.get('created_at', 'N/A')}")
            st.write(f"**Problem Type:** {model_info.get('problem_type', 'N/A')}")
        
        # Time range selection
        st.subheader("Monitoring Time Range")
        
        # Default to last 7 days
        end_date = datetime.now()
        start_date = end_date - timedelta(days=7)
        
        col1, col2 = st.columns(2)
        
        with col1:
            start_date = st.date_input("Start Date", value=start_date)
        
        with col2:
            end_date = st.date_input("End Date", value=end_date)
        
        # Convert to datetime
        start_datetime = datetime.combine(start_date, datetime.min.time())
        end_datetime = datetime.combine(end_date, datetime.max.time())
        
        # Get prediction logs
        prediction_logs = self._get_prediction_logs(selected_model, start_datetime, end_datetime)
        
        if not prediction_logs:
            st.info(f"No prediction logs found for {selected_model} in the selected time range.")
            
            # Generate mock data for demonstration
            st.subheader("Sample Monitoring Dashboard")
            st.warning("This is a sample dashboard with simulated data since no real logs are available.")
            
            # Generate sample data
            self._render_sample_monitoring_dashboard(model_info, start_datetime, end_datetime)
            
            return
        
        # Display monitoring dashboard
        self._render_monitoring_dashboard(model_info, prediction_logs)
    
    def _load_deployed_models(self):
        """Load information about deployed models."""
        models = {}
        
        if os.path.exists("models"):
            for model_dir in os.listdir("models"):
                metadata_path = os.path.join("models", model_dir, "metadata.json")
                
                if os.path.exists(metadata_path):
                    try:
                        with open(metadata_path, "r") as f:
                            metadata = json.load(f)
                        
                        models[model_dir] = metadata
                    except Exception as e:
                        st.warning(f"Error loading model metadata for {model_dir}: {e}")
        
        return models
    
    def _get_prediction_logs(self, model_name, start_datetime, end_datetime):
        """Get prediction logs for the selected model and time range."""
        logs = []
        
        # Check if model has prediction history
        if (model_name in st.session_state.prediction_history and 
            st.session_state.prediction_history[model_name]):
            
            # Get logs from prediction history
            for log in st.session_state.prediction_history[model_name]:
                log_time = datetime.fromisoformat(log["timestamp"])
                
                # Check if log is in time range
                if start_datetime <= log_time <= end_datetime:
                    logs.append(log)
        
        return logs
    
    def _render_monitoring_dashboard(self, model_info, prediction_logs):
        """Render monitoring dashboard for the selected model."""
        st.subheader("Monitoring Dashboard")
        
        # Convert logs to DataFrame
        logs_df = pd.DataFrame(prediction_logs)
        
        # Convert timestamp to datetime
        logs_df["timestamp"] = pd.to_datetime(logs_df["timestamp"])
        
        # Overview metrics
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("Total Predictions", len(logs_df))
        
        with col2:
            # Calculate prediction rate
            time_range = (logs_df["timestamp"].max() - logs_df["timestamp"].min()).total_seconds() / 3600  # in hours
            if time_range > 0:
                prediction_rate = len(logs_df) / time_range
                st.metric("Predictions/Hour", f"{prediction_rate:.2f}")
            else:
                st.metric("Predictions/Hour", "N/A")
        
        with col3:
            # Last prediction time
            if not logs_df.empty:
                last_prediction = logs_df["timestamp"].max().strftime("%Y-%m-%d %H:%M:%S")
                st.metric("Last Prediction", last_prediction)
            else:
                st.metric("Last Prediction", "N/A")
        
        # Predictions over time
        st.subheader("Predictions Over Time")
        
        # Group by hour
        logs_df["hour"] = logs_df["timestamp"].dt.floor("H")
        predictions_by_hour = logs_df.groupby("hour").size().reset_index(name="count")
        
        # Plot predictions over time
        fig = px.line(
            predictions_by_hour,
            x="hour",
            y="count",
            title="Prediction Volume Over Time",
            labels={"hour": "Time", "count": "Number of Predictions"}
        )
        
        st.plotly_chart(fig)
        
        # Prediction distribution
        st.subheader("Prediction Distribution")
        
        # Handle different problem types
        if model_info.get("problem_type") == "Classification":
            # For classification, show distribution of predicted classes
            pred_dist = logs_df["prediction"].value_counts().reset_index()
            pred_dist.columns = ["Class", "Count"]
            
            fig = px.pie(
                pred_dist,
                values="Count",
                names="Class",
                title="Distribution of Predicted Classes"
            )
            
            st.plotly_chart(fig)
        else:
            # For regression, show histogram of predicted values
            fig = px.histogram(
                logs_df,
                x="prediction",
                nbins=20,
                title="Distribution of Predicted Values",
                labels={"prediction": "Predicted Value", "count": "Frequency"}
            )
            
            st.plotly_chart(fig)
        
        # Feature values monitoring (if available)
        if "input" in logs_df.columns:
            st.subheader("Feature Value Monitoring")
            
            # Convert input dictionaries to separate columns
            input_df = pd.json_normalize([log["input"] for log in prediction_logs])
            
            if not input_df.empty:
                # Select feature to monitor
                feature_to_monitor = st.selectbox(
                    "Select Feature to Monitor",
                    options=input_df.columns
                )
                
                # Add timestamp from logs_df
                input_df["timestamp"] = logs_df["timestamp"]
                
                # Plot feature values over time
                fig = px.scatter(
                    input_df,
                    x="timestamp",
                    y=feature_to_monitor,
                    title=f"{feature_to_monitor} Values Over Time",
                    labels={"timestamp": "Time", feature_to_monitor: feature_to_monitor}
                )
                
                # Add trend line
                fig.add_trace(
                    go.Scatter(
                        x=input_df["timestamp"],
                        y=input_df[feature_to_monitor].rolling(window=min(5, len(input_df))).mean(),
                        mode='lines',
                        name='Moving Average',
                        line=dict(color='red')
                    )
                )
                
                st.plotly_chart(fig)
                
                # Feature distribution
                st.subheader(f"{feature_to_monitor} Distribution")
                
                fig = px.histogram(
                    input_df,
                    x=feature_to_monitor,
                    nbins=20,
                    title=f"Distribution of {feature_to_monitor}",
                    labels={feature_to_monitor: feature_to_monitor, "count": "Frequency"}
                )
                
                st.plotly_chart(fig)
    
    def _render_sample_monitoring_dashboard(self, model_info, start_datetime, end_datetime):
        """Render a sample monitoring dashboard when no real logs are available."""
        # Generate date range
        date_range = pd.date_range(start=start_datetime, end=end_datetime, freq="H")
        
        # Generate sample prediction counts
        np.random.seed(42)  # For reproducibility
        
        # Generate realistic pattern with daily seasonality
        hourly_pattern = np.sin(np.arange(24) * (2 * np.pi / 24)) + 1  # Daily pattern
        
        counts = []
        for dt in date_range:
            hour = dt.hour
            # Base count from hourly pattern plus some randomness
            count = int(hourly_pattern[hour] * 10 + np.random.normal(0, 2))
            count = max(0, count)  # Ensure non-negative
            counts.append(count)
        
        # Create DataFrame
        sample_data = pd.DataFrame({
            "timestamp": date_range,
            "count": counts
        })
        
        # Overview metrics
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("Total Predictions", sample_data["count"].sum())
        
        with col2:
            # Calculate prediction rate
            time_range = (end_datetime - start_datetime).total_seconds() / 3600  # in hours
            if time_range > 0:
                prediction_rate = sample_data["count"].sum() / time_range
                st.metric("Predictions/Hour", f"{prediction_rate:.2f}")
            else:
                st.metric("Predictions/Hour", "N/A")
        
        with col3:
            # Last prediction time
            last_prediction = end_datetime.strftime("%Y-%m-%d %H:%M:%S")
            st.metric("Last Prediction", last_prediction)
        
        # Predictions over time
        st.subheader("Sample Predictions Over Time")
        
        # Plot predictions over time
        fig = px.line(
            sample_data,
            x="timestamp",
            y="count",
            title="Prediction Volume Over Time (Sample Data)",
            labels={"timestamp": "Time", "count": "Number of Predictions"}
        )
        
        st.plotly_chart(fig)
        
        # Prediction distribution
        st.subheader("Sample Prediction Distribution")
        
        # Handle different problem types
        if model_info.get("problem_type") == "Classification":
            # For classification, show distribution of predicted classes
            # Generate sample class predictions
            classes = ["Class A", "Class B", "Class C"]
            class_counts = [60, 30, 10]  # Percentages
            
            pred_dist = pd.DataFrame({
                "Class": classes,
                "Count": [c * sample_data["count"].sum() // 100 for c in class_counts]
            })
            
            fig = px.pie(
                pred_dist,
                values="Count",
                names="Class",
                title="Distribution of Predicted Classes (Sample Data)"
            )
            
            st.plotly_chart(fig)
        else:
            # For regression, generate sample predicted values
            n_predictions = sample_data["count"].sum()
            sample_predictions = np.random.normal(50, 15, size=int(n_predictions))
            
            fig = px.histogram(
                sample_predictions,
                nbins=20,
                title="Distribution of Predicted Values (Sample Data)",
                labels={"value": "Predicted Value", "count": "Frequency"}
            )
            
            st.plotly_chart(fig)
        
        # Sample feature monitoring
        st.subheader("Sample Feature Value Monitoring")
        
        # Generate sample feature values
        n_samples = min(100, int(sample_data["count"].sum()))
        sample_timestamps = np.random.choice(sample_data["timestamp"], size=n_samples, replace=False)
        sample_timestamps.sort()
        
        feature_values = np.random.normal(25, 5, size=n_samples) + np.sin(np.arange(n_samples) * (2 * np.pi / n_samples)) * 3
        
        feature_df = pd.DataFrame({
            "timestamp": sample_timestamps,
            "feature_value": feature_values
        })
        
        # Plot feature values over time
        fig = px.scatter(
            feature_df,
            x="timestamp",
            y="feature_value",
            title="Sample Feature Values Over Time",
            labels={"timestamp": "Time", "feature_value": "Feature Value"}
        )
        
        # Add trend line
        fig.add_trace(
            go.Scatter(
                x=feature_df["timestamp"],
                y=feature_df["feature_value"].rolling(window=min(5, len(feature_df))).mean(),
                mode='lines',
                name='Moving Average',
                line=dict(color='red')
            )
        )
        
        st.plotly_chart(fig)
        
        # Feature distribution
        st.subheader("Sample Feature Distribution")
        
        fig = px.histogram(
            feature_df,
            x="feature_value",
            nbins=20,
            title="Distribution of Feature Values (Sample Data)",
            labels={"feature_value": "Feature Value", "count": "Frequency"}
        )
        
        st.plotly_chart(fig)
