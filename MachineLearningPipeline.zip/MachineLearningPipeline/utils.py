import os
import json
import joblib
import pandas as pd
from datetime import datetime

def create_directories():
    """Create necessary directories for the MLOps platform."""
    os.makedirs("models", exist_ok=True)
    os.makedirs("reports", exist_ok=True)
    os.makedirs("data", exist_ok=True)

def load_deployed_models():
    """Load metadata of all deployed models."""
    models = {}
    
    if os.path.exists("models"):
        for model_dir in os.listdir("models"):
            metadata_path = os.path.join("models", model_dir, "metadata.json")
            
            if os.path.exists(metadata_path):
                try:
                    with open(metadata_path, "r") as f:
                        metadata = json.load(f)
                    
                    models[model_dir] = metadata
                except Exception as e:
                    print(f"Error loading model metadata for {model_dir}: {e}")
    
    return models

def get_model_metadata(model_name):
    """Get metadata for a specific model."""
    metadata_path = os.path.join("models", model_name, "metadata.json")
    
    if os.path.exists(metadata_path):
        try:
            with open(metadata_path, "r") as f:
                return json.load(f)
        except Exception as e:
            print(f"Error loading model metadata for {model_name}: {e}")
    
    return None

def save_model(model, model_name, metadata=None, preprocessing_pipeline=None):
    """Save a model with its metadata and preprocessing pipeline."""
    # Create model directory
    model_dir = os.path.join("models", model_name)
    os.makedirs(model_dir, exist_ok=True)
    
    # Save model
    model_path = os.path.join(model_dir, "model.joblib")
    joblib.dump(model, model_path)
    
    # Save preprocessing pipeline if provided
    if preprocessing_pipeline is not None:
        pipeline_path = os.path.join(model_dir, "preprocessing_pipeline.joblib")
        joblib.dump(preprocessing_pipeline, pipeline_path)
    
    # Save metadata if provided
    if metadata is not None:
        # Add timestamp if not present
        if "created_at" not in metadata:
            metadata["created_at"] = datetime.now().isoformat()
        
        metadata_path = os.path.join(model_dir, "metadata.json")
        with open(metadata_path, "w") as f:
            json.dump(metadata, f, indent=2)
    
    return model_dir

def load_model(model_name):
    """Load a model and its preprocessing pipeline."""
    model_path = os.path.join("models", model_name, "model.joblib")
    pipeline_path = os.path.join("models", model_name, "preprocessing_pipeline.joblib")
    
    model = None
    pipeline = None
    
    # Load model
    if os.path.exists(model_path):
        try:
            model = joblib.load(model_path)
        except Exception as e:
            print(f"Error loading model: {e}")
    
    # Load preprocessing pipeline
    if os.path.exists(pipeline_path):
        try:
            pipeline = joblib.load(pipeline_path)
        except Exception as e:
            print(f"Error loading preprocessing pipeline: {e}")
    
    return model, pipeline

def preprocess_data(data, preprocessing_pipeline):
    """Preprocess data using a preprocessing pipeline."""
    if preprocessing_pipeline is not None:
        try:
            return preprocessing_pipeline.transform(data)
        except Exception as e:
            print(f"Error preprocessing data: {e}")
            return data
    
    return data

def get_prediction_logs(model_name, start_time=None, end_time=None):
    """Get prediction logs for a specific model within a time range."""
    logs_path = os.path.join("models", model_name, "prediction_logs.csv")
    
    if os.path.exists(logs_path):
        try:
            logs = pd.read_csv(logs_path)
            logs["timestamp"] = pd.to_datetime(logs["timestamp"])
            
            # Filter by time range if provided
            if start_time is not None:
                logs = logs[logs["timestamp"] >= start_time]
            
            if end_time is not None:
                logs = logs[logs["timestamp"] <= end_time]
            
            return logs
        except Exception as e:
            print(f"Error loading prediction logs: {e}")
    
    return pd.DataFrame()
