import streamlit as st
import pandas as pd
import numpy as np
import joblib
import os
import json
from datetime import datetime

class ModelDeployer:
    def __init__(self):
        # Create necessary directories
        os.makedirs("models", exist_ok=True)
        
    def render(self):
        st.header("Model Deployment")
        
        tabs = st.tabs(["Deploy Model", "Inference"])
        
        # Deploy Model Tab
        with tabs[0]:
            self._render_deployment_tab()
            
        # Inference Tab
        with tabs[1]:
            self._render_inference_tab()
    
    def _render_deployment_tab(self):
        """Render the deployment tab interface."""
        st.subheader("Deploy Trained Model")
        
        # Check if model is trained
        if st.session_state.model is None:
            st.info("Please train a model first.")
            return
        
        # Model information
        st.subheader("Model Information")
        
        # Display model type
        st.write(f"**Model Type:** {type(st.session_state.model).__name__}")
        
        # Display model parameters
        st.write("**Model Parameters:**")
        params = st.session_state.model.get_params()
        params_df = pd.DataFrame(list(params.items()), columns=["Parameter", "Value"])
        st.dataframe(params_df)
        
        # Display model metrics if available
        if st.session_state.metrics is not None:
            st.write("**Model Metrics:**")
            metrics_df = pd.DataFrame(list(st.session_state.metrics.items()), columns=["Metric", "Value"])
            st.dataframe(metrics_df)
        
        # Model name input
        model_name = st.text_input(
            "Model Name",
            value=f"{type(st.session_state.model).__name__}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        )
        
        # Model description
        model_description = st.text_area(
            "Model Description",
            value=f"Trained {type(st.session_state.model).__name__} model on {datetime.now().strftime('%Y-%m-%d')}"
        )
        
        # Model version
        model_version = st.text_input("Model Version", "1.0.0")
        
        # Deploy button
        if st.button("Deploy Model"):
            # Check if model name is valid
            if not model_name:
                st.error("Please provide a valid model name.")
                return
            
            # Create model directory
            model_dir = os.path.join("models", model_name)
            os.makedirs(model_dir, exist_ok=True)
            
            # Save model
            model_path = os.path.join(model_dir, "model.joblib")
            joblib.dump(st.session_state.model, model_path)
            
            # Save preprocessing pipeline if available
            if st.session_state.preprocessing_pipeline is not None:
                pipeline_path = os.path.join(model_dir, "preprocessing_pipeline.joblib")
                joblib.dump(st.session_state.preprocessing_pipeline, pipeline_path)
            
            # Save metadata
            metadata = {
                "name": model_name,
                "description": model_description,
                "version": model_version,
                "model_type": type(st.session_state.model).__name__,
                "created_at": datetime.now().isoformat(),
                "metrics": st.session_state.metrics,
                "feature_names": st.session_state.feature_names.tolist() if hasattr(st.session_state.feature_names, 'tolist') else st.session_state.feature_names,
                "problem_type": self._determine_problem_type()
            }
            
            # Save metadata
            metadata_path = os.path.join(model_dir, "metadata.json")
            with open(metadata_path, "w") as f:
                json.dump(metadata, f, indent=2)
            
            # Success message
            st.success(f"Model deployed successfully to {model_dir}")
            
            # Update deployed models list
            st.session_state.deployed_models = self._load_deployed_models()
    
    def _render_inference_tab(self):
        """Render the inference tab interface."""
        st.subheader("Model Inference")
        
        # Load deployed models
        deployed_models = self._load_deployed_models()
        
        if not deployed_models:
            st.info("No deployed models found. Please deploy a model first.")
            return
        
        # Select deployed model
        selected_model_name = st.selectbox(
            "Select Deployed Model",
            options=list(deployed_models.keys()),
            index=0 if st.session_state.selected_deployed_model is None else list(deployed_models.keys()).index(st.session_state.selected_deployed_model)
        )
        
        # Store selected model in session state
        st.session_state.selected_deployed_model = selected_model_name
        
        # Get selected model details
        model_info = deployed_models[selected_model_name]
        model_path = os.path.join("models", selected_model_name, "model.joblib")
        
        # Load model if not already loaded
        if not hasattr(st, "_loaded_model") or st._loaded_model_name != selected_model_name:
            with st.spinner("Loading model..."):
                try:
                    st._loaded_model = joblib.load(model_path)
                    st._loaded_model_name = selected_model_name
                    
                    # Load preprocessing pipeline if available
                    pipeline_path = os.path.join("models", selected_model_name, "preprocessing_pipeline.joblib")
                    if os.path.exists(pipeline_path):
                        st._loaded_pipeline = joblib.load(pipeline_path)
                    else:
                        st._loaded_pipeline = None
                    
                    st.success("Model loaded successfully!")
                except Exception as e:
                    st.error(f"Error loading model: {e}")
                    return
        
        # Display model information
        st.subheader("Model Information")
        
        st.write(f"**Name:** {model_info.get('name', 'N/A')}")
        st.write(f"**Description:** {model_info.get('description', 'N/A')}")
        st.write(f"**Version:** {model_info.get('version', 'N/A')}")
        st.write(f"**Model Type:** {model_info.get('model_type', 'N/A')}")
        st.write(f"**Created At:** {model_info.get('created_at', 'N/A')}")
        st.write(f"**Problem Type:** {model_info.get('problem_type', 'N/A')}")
        
        # Input method selection
        input_method = st.radio(
            "Input Method",
            options=["Manual Input", "CSV Upload"],
            horizontal=True
        )
        
        # Get feature names from metadata
        feature_names = model_info.get("feature_names", [])
        
        if input_method == "Manual Input":
            # Create input form
            st.subheader("Input Data")
            
            # Create input fields for each feature
            input_data = {}
            
            # Create columns to display inputs in a grid
            cols = st.columns(3)
            for i, feature in enumerate(feature_names):
                with cols[i % 3]:
                    input_data[feature] = st.number_input(
                        f"{feature}",
                        value=0.0,
                        key=f"input_{feature}"
                    )
            
            # Make prediction button
            if st.button("Make Prediction"):
                # Create input DataFrame
                input_df = pd.DataFrame([input_data])
                
                # Make prediction
                prediction = self._make_prediction(input_df)
                
                # Display prediction
                st.subheader("Prediction Result")
                
                prediction_value = prediction[0]
                
                # Display differently based on problem type
                problem_type = model_info.get("problem_type", "Classification")
                
                if problem_type == "Classification":
                    st.metric("Predicted Class", prediction_value)
                    
                    # Get probability if available
                    if hasattr(st._loaded_model, "predict_proba"):
                        try:
                            probabilities = st._loaded_model.predict_proba(self._preprocess_input(input_df))[0]
                            
                            # Display probabilities
                            st.subheader("Class Probabilities")
                            
                            proba_df = pd.DataFrame({
                                "Class": st._loaded_model.classes_,
                                "Probability": probabilities
                            })
                            
                            # Sort by probability
                            proba_df = proba_df.sort_values("Probability", ascending=False)
                            
                            # Create bar chart
                            fig = px.bar(
                                proba_df,
                                x="Class",
                                y="Probability",
                                title="Prediction Probabilities",
                                text_auto='.2%'
                            )
                            
                            st.plotly_chart(fig)
                        except Exception as e:
                            st.warning(f"Could not calculate probabilities: {e}")
                
                else:  # Regression
                    st.metric("Predicted Value", f"{prediction_value:.4f}")
                
                # Save prediction to history
                timestamp = datetime.now().isoformat()
                if selected_model_name not in st.session_state.prediction_history:
                    st.session_state.prediction_history[selected_model_name] = []
                
                st.session_state.prediction_history[selected_model_name].append({
                    "timestamp": timestamp,
                    "input": input_data,
                    "prediction": prediction_value,
                    "model_name": selected_model_name
                })
        
        else:  # CSV Upload
            st.subheader("Upload Data")
            
            uploaded_file = st.file_uploader("Upload CSV file", type="csv")
            
            if uploaded_file is not None:
                try:
                    # Load data
                    input_df = pd.read_csv(uploaded_file)
                    
                    # Display data preview
                    st.subheader("Data Preview")
                    st.dataframe(input_df.head())
                    
                    # Check features
                    missing_features = [f for f in feature_names if f not in input_df.columns]
                    if missing_features:
                        st.warning(f"Missing features in uploaded data: {', '.join(missing_features)}")
                    
                    # Make prediction button
                    if st.button("Make Batch Predictions"):
                        # Make predictions
                        predictions = self._make_prediction(input_df)
                        
                        # Add predictions to input data
                        result_df = input_df.copy()
                        result_df["prediction"] = predictions
                        
                        # Display results
                        st.subheader("Prediction Results")
                        st.dataframe(result_df)
                        
                        # Download button
                        csv = result_df.to_csv(index=False)
                        st.download_button(
                            label="Download Results",
                            data=csv,
                            file_name=f"predictions_{selected_model_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                            mime="text/csv"
                        )
                
                except Exception as e:
                    st.error(f"Error processing file: {e}")
        
        # Prediction History
        if selected_model_name in st.session_state.prediction_history and st.session_state.prediction_history[selected_model_name]:
            st.subheader("Prediction History")
            
            # Create DataFrame from prediction history
            history = st.session_state.prediction_history[selected_model_name]
            
            # Convert to DataFrame
            history_df = pd.DataFrame(history)
            
            # Format timestamp
            history_df["timestamp"] = pd.to_datetime(history_df["timestamp"]).dt.strftime("%Y-%m-%d %H:%M:%S")
            
            # Display history
            st.dataframe(history_df[["timestamp", "prediction"]])
            
            # Clear history button
            if st.button("Clear History"):
                st.session_state.prediction_history[selected_model_name] = []
                st.rerun()
    
    def _load_deployed_models(self):
        """Load information about deployed models."""
        models = {}
        
        if os.path.exists("models"):
            for model_dir in os.listdir("models"):
                metadata_path = os.path.join("models", model_dir, "metadata.json")
                
                if os.path.exists(metadata_path):
                    try:
                        with open(metadata_path, "r") as f:
                            metadata = json.load(f)
                        
                        models[model_dir] = metadata
                    except Exception as e:
                        st.warning(f"Error loading model metadata for {model_dir}: {e}")
        
        return models
    
    def _determine_problem_type(self):
        """Determine if the problem is classification or regression based on target values."""
        y_unique = len(np.unique(st.session_state.y_train))
        
        # If number of unique values is small, it's likely classification
        if y_unique <= 10:
            return "Classification"
        else:
            return "Regression"
    
    def _preprocess_input(self, input_df):
        """Preprocess input data using saved preprocessing pipeline."""
        if hasattr(st, "_loaded_pipeline") and st._loaded_pipeline is not None:
            try:
                # Apply preprocessing pipeline
                return st._loaded_pipeline.transform(input_df)
            except Exception as e:
                st.error(f"Error preprocessing input: {e}")
                return input_df
        
        return input_df
    
    def _make_prediction(self, input_df):
        """Make prediction using loaded model."""
        if hasattr(st, "_loaded_model"):
            try:
                # Preprocess input data
                processed_input = self._preprocess_input(input_df)
                
                # Make prediction
                return st._loaded_model.predict(processed_input)
            except Exception as e:
                st.error(f"Error making prediction: {e}")
                return []
        
        return []
