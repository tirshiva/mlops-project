import streamlit as st
import pandas as pd
import numpy as np
import time
import joblib
import os
from datetime import datetime
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor, GradientBoostingClassifier, GradientBoostingRegressor
from sklearn.svm import SVC, SVR
from sklearn.neighbors import KNeighborsClassifier, KNeighborsRegressor
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

class ModelTrainer:
    def render(self):
        st.header("Model Training")
        
        # Check if data is preprocessed
        if (st.session_state.X_train is None or 
            st.session_state.X_test is None or 
            st.session_state.y_train is None or 
            st.session_state.y_test is None):
            st.info("Please complete data preprocessing first.")
            return
        
        # Determine problem type (classification or regression)
        problem_type = self._determine_problem_type()
        
        # Display problem type
        st.subheader("Problem Type")
        st.info(f"Detected problem type: **{problem_type}**")
        
        # Model selection
        st.subheader("Model Selection")
        
        if problem_type == "Classification":
            model_options = {
                "Logistic Regression": LogisticRegression,
                "Random Forest": RandomForestClassifier,
                "Gradient Boosting": GradientBoostingClassifier,
                "SVM": SVC,
                "K-Nearest Neighbors": KNeighborsClassifier,
                "Decision Tree": DecisionTreeClassifier
            }
        else:  # Regression
            model_options = {
                "Linear Regression": LinearRegression,
                "Random Forest": RandomForestRegressor,
                "Gradient Boosting": GradientBoostingRegressor,
                "SVM": SVR,
                "K-Nearest Neighbors": KNeighborsRegressor,
                "Decision Tree": DecisionTreeRegressor
            }
        
        selected_model = st.selectbox(
            "Select a model to train",
            options=list(model_options.keys())
        )
        
        # Hyperparameter configuration
        st.subheader("Hyperparameter Configuration")
        
        hyperparams = {}
        
        if selected_model == "Logistic Regression" or selected_model == "Linear Regression":
            if selected_model == "Logistic Regression":
                hyperparams["C"] = st.number_input("Regularization strength (C)", min_value=0.01, max_value=10.0, value=1.0, step=0.1)
                hyperparams["solver"] = st.selectbox("Solver", options=["liblinear", "lbfgs", "newton-cg", "sag", "saga"])
                hyperparams["max_iter"] = st.number_input("Maximum iterations", min_value=100, max_value=10000, value=1000, step=100)
            
        elif selected_model == "Random Forest":
            hyperparams["n_estimators"] = st.slider("Number of trees", min_value=10, max_value=500, value=100, step=10)
            hyperparams["max_depth"] = st.slider("Maximum depth", min_value=1, max_value=50, value=None)
            hyperparams["min_samples_split"] = st.slider("Minimum samples to split", min_value=2, max_value=20, value=2)
            hyperparams["min_samples_leaf"] = st.slider("Minimum samples in leaf", min_value=1, max_value=20, value=1)
            
        elif selected_model == "Gradient Boosting":
            hyperparams["n_estimators"] = st.slider("Number of boosting stages", min_value=10, max_value=500, value=100, step=10)
            hyperparams["learning_rate"] = st.number_input("Learning rate", min_value=0.001, max_value=1.0, value=0.1, step=0.01)
            hyperparams["max_depth"] = st.slider("Maximum depth", min_value=1, max_value=20, value=3)
            hyperparams["subsample"] = st.slider("Subsample ratio", min_value=0.1, max_value=1.0, value=1.0, step=0.1)
            
        elif selected_model == "SVM":
            hyperparams["C"] = st.number_input("Regularization parameter (C)", min_value=0.01, max_value=100.0, value=1.0, step=0.1)
            hyperparams["kernel"] = st.selectbox("Kernel", options=["linear", "poly", "rbf", "sigmoid"])
            if hyperparams["kernel"] != "linear":
                hyperparams["gamma"] = st.selectbox("Kernel coefficient (gamma)", options=["scale", "auto"])
                
        elif selected_model == "K-Nearest Neighbors":
            hyperparams["n_neighbors"] = st.slider("Number of neighbors", min_value=1, max_value=50, value=5)
            hyperparams["weights"] = st.selectbox("Weight function", options=["uniform", "distance"])
            hyperparams["algorithm"] = st.selectbox("Algorithm", options=["auto", "ball_tree", "kd_tree", "brute"])
            
        elif selected_model == "Decision Tree":
            hyperparams["max_depth"] = st.slider("Maximum depth", min_value=1, max_value=50, value=None)
            hyperparams["min_samples_split"] = st.slider("Minimum samples to split", min_value=2, max_value=20, value=2)
            hyperparams["min_samples_leaf"] = st.slider("Minimum samples in leaf", min_value=1, max_value=20, value=1)
            hyperparams["criterion"] = st.selectbox(
                "Split quality criterion", 
                options=["gini", "entropy"] if problem_type == "Classification" else ["squared_error", "absolute_error"]
            )
        
        # Add common parameters
        hyperparams["random_state"] = 42
        
        # Train model button
        if st.button("Train Model"):
            with st.spinner("Training model..."):
                # Initialize and train the model
                model_class = model_options[selected_model]
                
                # Create the model with selected hyperparameters
                # Handle the case where max_depth is None
                if "max_depth" in hyperparams and hyperparams["max_depth"] is None:
                    hyperparams["max_depth"] = None
                
                model = model_class(**hyperparams)
                
                # Fit the model
                start_time = time.time()
                model.fit(st.session_state.X_train, st.session_state.y_train)
                training_time = time.time() - start_time
                
                # Store the model in session state
                st.session_state.model = model
                
                # Compute predictions
                y_pred = model.predict(st.session_state.X_test)
                
                # Calculate metrics
                metrics = {}
                if problem_type == "Classification":
                    # Check if it's binary or multiclass
                    if len(np.unique(st.session_state.y_train)) <= 2:
                        metrics["accuracy"] = accuracy_score(st.session_state.y_test, y_pred)
                        metrics["precision"] = precision_score(st.session_state.y_test, y_pred, zero_division=0)
                        metrics["recall"] = recall_score(st.session_state.y_test, y_pred, zero_division=0)
                        metrics["f1"] = f1_score(st.session_state.y_test, y_pred, zero_division=0)
                        
                        # AUC-ROC (if predict_proba is available)
                        if hasattr(model, "predict_proba"):
                            try:
                                y_prob = model.predict_proba(st.session_state.X_test)[:, 1]
                                metrics["roc_auc"] = roc_auc_score(st.session_state.y_test, y_prob)
                            except:
                                metrics["roc_auc"] = None
                    else:
                        # Multiclass metrics
                        metrics["accuracy"] = accuracy_score(st.session_state.y_test, y_pred)
                        metrics["precision"] = precision_score(st.session_state.y_test, y_pred, average='weighted', zero_division=0)
                        metrics["recall"] = recall_score(st.session_state.y_test, y_pred, average='weighted', zero_division=0)
                        metrics["f1"] = f1_score(st.session_state.y_test, y_pred, average='weighted', zero_division=0)
                else:
                    # Regression metrics
                    metrics["mse"] = mean_squared_error(st.session_state.y_test, y_pred)
                    metrics["rmse"] = np.sqrt(metrics["mse"])
                    metrics["mae"] = mean_absolute_error(st.session_state.y_test, y_pred)
                    metrics["r2"] = r2_score(st.session_state.y_test, y_pred)
                
                metrics["training_time"] = training_time
                
                # Store metrics in session state
                st.session_state.metrics = metrics
                
                # Display success message
                st.success(f"Model trained successfully in {training_time:.2f} seconds!")
                
                # Display metrics
                st.subheader("Model Performance Metrics")
                
                # Create metrics table
                metrics_df = pd.DataFrame(metrics.items(), columns=["Metric", "Value"])
                metrics_df.set_index("Metric", inplace=True)
                
                # Format metrics
                for metric in metrics_df.index:
                    if metric != "training_time":
                        metrics_df.loc[metric, "Value"] = f"{metrics_df.loc[metric, 'Value']:.4f}"
                    else:
                        metrics_df.loc[metric, "Value"] = f"{metrics_df.loc[metric, 'Value']:.2f} seconds"
                
                st.dataframe(metrics_df)
    
    def _determine_problem_type(self):
        """Determine if the problem is classification or regression based on target values."""
        y_unique = len(np.unique(st.session_state.y_train))
        
        # If number of unique values is small, it's likely classification
        if y_unique <= 10:
            return "Classification"
        else:
            return "Regression"
