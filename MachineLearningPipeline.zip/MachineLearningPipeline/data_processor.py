import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
from sklearn.preprocessing import StandardScaler, MinMaxScaler, OneHotEncoder, LabelEncoder
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split

class DataProcessor:
    def render(self):
        st.header("Data Preprocessing")
        
        if st.session_state.data is None:
            st.info("Please upload data in the Data Ingestion tab first.")
            return
        
        data = st.session_state.data
        
        # Target column selection
        st.subheader("Target Variable Selection")
        columns_list = data.columns.tolist()
        
        # Reset target column if it doesn't exist in current dataset
        if st.session_state.target_column is not None and st.session_state.target_column not in columns_list:
            st.session_state.target_column = None
            
        # Select a default index (last column or first if no columns)
        default_index = len(columns_list) - 1 if columns_list else 0
        
        target_column = st.selectbox(
            "Select the target variable",
            options=columns_list,
            index=default_index if st.session_state.target_column is None 
                  else columns_list.index(st.session_state.target_column)
        )
        st.session_state.target_column = target_column
        
        # Display target variable distribution
        st.subheader(f"Target Variable ({target_column}) Distribution")
        
        # Different visualization based on target variable type
        if data[target_column].dtype == 'object' or data[target_column].nunique() < 10:
            # Categorical target
            fig = px.histogram(data, x=target_column, color=target_column)
            st.plotly_chart(fig)
            
            # Display class balance
            st.subheader("Class Balance")
            class_counts = data[target_column].value_counts()
            st.dataframe(class_counts)
            
        else:
            # Numerical target
            fig = px.histogram(data, x=target_column)
            st.plotly_chart(fig)
            
            # Display statistics
            st.subheader("Target Statistics")
            st.dataframe(data[target_column].describe().to_frame())
        
        # Data cleaning options
        st.subheader("Data Cleaning")
        
        # Handle missing values
        missing_values = data.isnull().sum()
        columns_with_missing = missing_values[missing_values > 0]
        
        if not columns_with_missing.empty:
            st.warning(f"Found {len(columns_with_missing)} columns with missing values")
            st.dataframe(columns_with_missing.to_frame(name="Missing Count"))
            
            missing_strategy = st.selectbox(
                "Select strategy for handling missing values",
                options=["Drop rows with missing values", "Fill numerical with mean", "Fill numerical with median", "Fill categorical with mode"]
            )
            
            if st.button("Apply Missing Value Strategy"):
                if missing_strategy == "Drop rows with missing values":
                    data = data.dropna()
                    st.success(f"Dropped rows with missing values. New shape: {data.shape}")
                
                elif missing_strategy == "Fill numerical with mean":
                    numerical_cols = data.select_dtypes(include=['int64', 'float64']).columns
                    for col in numerical_cols:
                        if data[col].isnull().sum() > 0:
                            data[col] = data[col].fillna(data[col].mean())
                    st.success("Filled numerical missing values with mean")
                
                elif missing_strategy == "Fill numerical with median":
                    numerical_cols = data.select_dtypes(include=['int64', 'float64']).columns
                    for col in numerical_cols:
                        if data[col].isnull().sum() > 0:
                            data[col] = data[col].fillna(data[col].median())
                    st.success("Filled numerical missing values with median")
                
                elif missing_strategy == "Fill categorical with mode":
                    categorical_cols = data.select_dtypes(include=['object']).columns
                    for col in categorical_cols:
                        if data[col].isnull().sum() > 0:
                            data[col] = data[col].fillna(data[col].mode()[0])
                    st.success("Filled categorical missing values with mode")
        
        # Handle duplicate rows
        duplicate_count = data.duplicated().sum()
        if duplicate_count > 0:
            st.warning(f"Found {duplicate_count} duplicate rows")
            if st.button("Remove Duplicate Rows"):
                data = data.drop_duplicates()
                st.success(f"Removed duplicate rows. New shape: {data.shape}")
        
        # Feature engineering
        st.subheader("Feature Engineering")
        
        # Identify numerical and categorical columns
        numerical_cols = data.select_dtypes(include=['int64', 'float64']).columns.tolist()
        categorical_cols = data.select_dtypes(include=['object']).columns.tolist()
        
        # Remove target column from feature lists
        if target_column in numerical_cols:
            numerical_cols.remove(target_column)
        if target_column in categorical_cols:
            categorical_cols.remove(target_column)
        
        # Feature selection
        st.subheader("Feature Selection")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.write("Numerical Features")
            selected_numerical = []
            for col in numerical_cols:
                if st.checkbox(f"{col}", value=True, key=f"num_{col}"):
                    selected_numerical.append(col)
        
        with col2:
            st.write("Categorical Features")
            selected_categorical = []
            for col in categorical_cols:
                if st.checkbox(f"{col}", value=True, key=f"cat_{col}"):
                    selected_categorical.append(col)
        
        # Scaling options for numerical features
        scaling_method = None
        encoding_method = None
        
        if selected_numerical:
            st.subheader("Numerical Feature Scaling")
            scaling_method = st.selectbox(
                "Select scaling method for numerical features",
                options=["None", "StandardScaler", "MinMaxScaler"]
            )
        
        # Encoding options for categorical features
        if selected_categorical:
            st.subheader("Categorical Feature Encoding")
            encoding_method = st.selectbox(
                "Select encoding method for categorical features",
                options=["None", "OneHotEncoder", "LabelEncoder"]
            )
        
        # Train-test split options
        st.subheader("Train-Test Split")
        test_size = st.slider("Test set size (%)", min_value=10, max_value=50, value=20) / 100
        random_state = st.number_input("Random state", min_value=0, max_value=999, value=42)
        
        # Process data button
        if st.button("Process Data"):
            # Create the preprocessing pipeline
            preprocessing_steps = []
            
            # Numerical preprocessing
            if selected_numerical and scaling_method != "None":
                if scaling_method == "StandardScaler":
                    num_pipeline = Pipeline([
                        ('imputer', SimpleImputer(strategy='mean')),
                        ('scaler', StandardScaler())
                    ])
                elif scaling_method == "MinMaxScaler":
                    num_pipeline = Pipeline([
                        ('imputer', SimpleImputer(strategy='mean')),
                        ('scaler', MinMaxScaler())
                    ])
                
                preprocessing_steps.append(('num', num_pipeline, selected_numerical))
            
            # Categorical preprocessing
            if selected_categorical and encoding_method != "None":
                if encoding_method == "OneHotEncoder":
                    cat_pipeline = Pipeline([
                        ('imputer', SimpleImputer(strategy='most_frequent')),
                        ('onehot', OneHotEncoder(handle_unknown='ignore'))
                    ])
                    preprocessing_steps.append(('cat', cat_pipeline, selected_categorical))
                elif encoding_method == "LabelEncoder":
                    # We'll handle LabelEncoder separately as it doesn't work directly in ColumnTransformer
                    pass
            
            # Create and fit preprocessing pipeline
            if preprocessing_steps:
                preprocessor = ColumnTransformer(
                    transformers=preprocessing_steps,
                    remainder='drop'
                )
                
                # Create X and y
                X = data.drop(columns=[target_column])
                y = data[target_column]
                
                # Handle LabelEncoder for the target if it's categorical
                if y.dtype == 'object':
                    label_encoder = LabelEncoder()
                    y = label_encoder.fit_transform(y)
                
                # Train-test split
                X_train, X_test, y_train, y_test = train_test_split(
                    X, y, test_size=test_size, random_state=random_state
                )
                
                # Apply preprocessing
                X_train_processed = preprocessor.fit_transform(X_train)
                X_test_processed = preprocessor.transform(X_test)
                
                # Apply LabelEncoder to categorical features if selected
                if selected_categorical and encoding_method == "LabelEncoder":
                    label_encoders = {}
                    for col in selected_categorical:
                        le = LabelEncoder()
                        X_train[col] = le.fit_transform(X_train[col].astype(str))
                        X_test[col] = le.transform(X_test[col].astype(str))
                        label_encoders[col] = le
                    
                    # Update X_train_processed and X_test_processed
                    X_train_processed = X_train[selected_numerical + selected_categorical].values
                    X_test_processed = X_test[selected_numerical + selected_categorical].values
                
                # Get feature names
                if hasattr(preprocessor, 'get_feature_names_out'):
                    feature_names = preprocessor.get_feature_names_out()
                else:
                    feature_names = selected_numerical.copy()
                    if selected_categorical and encoding_method == "LabelEncoder":
                        feature_names.extend(selected_categorical)
                    elif selected_categorical and encoding_method == "OneHotEncoder":
                        cat_encoder = preprocessor.named_transformers_['cat'].named_steps['onehot']
                        for i, cat in enumerate(selected_categorical):
                            feature_names.extend([f"{cat}_{val}" for val in cat_encoder.categories_[i]])
                
                # Store in session state
                st.session_state.X_train = X_train_processed
                st.session_state.X_test = X_test_processed
                st.session_state.y_train = y_train
                st.session_state.y_test = y_test
                st.session_state.preprocessing_pipeline = preprocessor
                st.session_state.feature_names = feature_names
                
                # Success message
                st.success("Data preprocessing completed successfully!")
                
                # Display processed data information
                st.subheader("Processed Data Information")
                st.write(f"Training set shape: {X_train_processed.shape}")
                st.write(f"Testing set shape: {X_test_processed.shape}")
                
                # Display a sample of processed features
                if isinstance(X_train_processed, np.ndarray):
                    processed_sample = pd.DataFrame(
                        X_train_processed[:5],
                        columns=feature_names if len(feature_names) == X_train_processed.shape[1] else None
                    )
                else:  # Sparse matrix
                    processed_sample = pd.DataFrame(
                        X_train_processed[:5].toarray(),
                        columns=feature_names if len(feature_names) == X_train_processed.shape[1] else None
                    )
                    
                st.subheader("Processed Features Sample")
                st.dataframe(processed_sample)
            
            else:
                st.error("No preprocessing steps selected. Please select at least one feature and preprocessing method.")
