import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import plotly.graph_objects as go
from sklearn.metrics import confusion_matrix, roc_curve, precision_recall_curve, auc
from sklearn.inspection import permutation_importance

class ModelEvaluator:
    def render(self):
        st.header("Model Evaluation")
        
        # Check if model is trained
        if st.session_state.model is None or st.session_state.metrics is None:
            st.info("Please train a model first.")
            return
        
        # Determine problem type
        problem_type = self._determine_problem_type()
        
        # Performance Metrics Section
        st.subheader("Performance Metrics")
        
        # Create metrics cards layout
        metrics = st.session_state.metrics
        
        # Display metrics based on problem type
        if problem_type == "Classification":
            cols = st.columns(4)
            with cols[0]:
                st.metric("Accuracy", f"{metrics.get('accuracy', 0):.4f}")
            with cols[1]:
                st.metric("Precision", f"{metrics.get('precision', 0):.4f}")
            with cols[2]:
                st.metric("Recall", f"{metrics.get('recall', 0):.4f}")
            with cols[3]:
                st.metric("F1 Score", f"{metrics.get('f1', 0):.4f}")
                
            if metrics.get('roc_auc') is not None:
                st.metric("ROC AUC", f"{metrics.get('roc_auc', 0):.4f}")
        else:
            cols = st.columns(4)
            with cols[0]:
                st.metric("MSE", f"{metrics.get('mse', 0):.4f}")
            with cols[1]:
                st.metric("RMSE", f"{metrics.get('rmse', 0):.4f}")
            with cols[2]:
                st.metric("MAE", f"{metrics.get('mae', 0):.4f}")
            with cols[3]:
                st.metric("R² Score", f"{metrics.get('r2', 0):.4f}")
        
        # Training Information
        st.subheader("Training Information")
        
        cols = st.columns(3)
        with cols[0]:
            st.metric("Training Time", f"{metrics.get('training_time', 0):.2f} seconds")
        with cols[1]:
            st.metric("Training Samples", st.session_state.X_train.shape[0])
        with cols[2]:
            st.metric("Test Samples", st.session_state.X_test.shape[0])
        
        # Plot visualizations based on problem type
        if problem_type == "Classification":
            self._render_classification_evaluation()
        else:
            self._render_regression_evaluation()
        
        # Feature Importance section
        st.subheader("Feature Importance")
        
        # Get feature importance (if available in model)
        if hasattr(st.session_state.model, 'feature_importances_'):
            feature_importance = st.session_state.model.feature_importances_
            feature_names = st.session_state.feature_names
            
            # Sort feature importance
            if len(feature_names) == len(feature_importance):
                sorted_idx = np.argsort(feature_importance)
                feature_importance_df = pd.DataFrame({
                    'Feature': [feature_names[i] for i in sorted_idx],
                    'Importance': feature_importance[sorted_idx]
                })
                
                # Plot feature importance
                fig = px.bar(
                    feature_importance_df, 
                    x='Importance', 
                    y='Feature', 
                    orientation='h',
                    title='Feature Importance'
                )
                st.plotly_chart(fig)
            else:
                st.warning(f"Feature names length ({len(feature_names)}) doesn't match feature importance length ({len(feature_importance)})")
        else:
            st.info("Feature importance not available for this model type.")
            
            # Use permutation importance as an alternative
            with st.spinner("Calculating permutation importance..."):
                try:
                    result = permutation_importance(
                        st.session_state.model, 
                        st.session_state.X_test, 
                        st.session_state.y_test,
                        n_repeats=5,
                        random_state=42
                    )
                    
                    feature_names = st.session_state.feature_names
                    perm_importance = result.importances_mean
                    
                    if len(feature_names) == len(perm_importance):
                        sorted_idx = np.argsort(perm_importance)
                        feature_importance_df = pd.DataFrame({
                            'Feature': [feature_names[i] for i in sorted_idx],
                            'Importance': perm_importance[sorted_idx]
                        })
                        
                        # Plot permutation importance
                        fig = px.bar(
                            feature_importance_df, 
                            x='Importance', 
                            y='Feature', 
                            orientation='h',
                            title='Permutation Feature Importance'
                        )
                        st.plotly_chart(fig)
                    else:
                        st.warning(f"Feature names length ({len(feature_names)}) doesn't match permutation importance length ({len(perm_importance)})")
                except Exception as e:
                    st.error(f"Error calculating permutation importance: {e}")
        
        # Save Evaluation Report Section
        st.subheader("Save Evaluation Report")
        
        report_name = st.text_input("Report name", f"model_evaluation_{problem_type.lower()}_{pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')}")
        
        if st.button("Save Evaluation Report"):
            # Create evaluation report
            report_data = {
                "model_type": str(type(st.session_state.model).__name__),
                "problem_type": problem_type,
                "metrics": metrics,
                "timestamp": pd.Timestamp.now().isoformat(),
                "samples": {
                    "train": st.session_state.X_train.shape[0],
                    "test": st.session_state.X_test.shape[0]
                }
            }
            
            # Convert to DataFrame for easy saving
            report_df = pd.DataFrame([report_data])
            
            # Create directory if it doesn't exist
            os.makedirs("reports", exist_ok=True)
            
            # Save report
            report_path = f"reports/{report_name}.csv"
            report_df.to_csv(report_path, index=False)
            
            st.success(f"Evaluation report saved to {report_path}")
    
    def _determine_problem_type(self):
        """Determine if the problem is classification or regression based on target values."""
        y_unique = len(np.unique(st.session_state.y_train))
        
        # If number of unique values is small, it's likely classification
        if y_unique <= 10:
            return "Classification"
        else:
            return "Regression"
    
    def _render_classification_evaluation(self):
        """Render classification-specific evaluation visualizations."""
        # Get predictions
        y_pred = st.session_state.model.predict(st.session_state.X_test)
        
        # Confusion Matrix
        st.subheader("Confusion Matrix")
        
        # Get class labels
        classes = np.unique(np.concatenate([st.session_state.y_test, y_pred]))
        
        # Generate confusion matrix
        cm = confusion_matrix(st.session_state.y_test, y_pred)
        
        # Create heatmap with Plotly
        fig = go.Figure(data=go.Heatmap(
            z=cm,
            x=classes,
            y=classes,
            colorscale='Blues',
            text=cm,
            texttemplate="%{text}",
            textfont={"size": 12},
        ))
        
        fig.update_layout(
            title="Confusion Matrix",
            xaxis_title="Predicted Label",
            yaxis_title="True Label",
            xaxis_dtick=1,
            yaxis_dtick=1,
            width=600,
            height=500,
        )
        
        st.plotly_chart(fig)
        
        # ROC Curve (for binary classification)
        if len(classes) == 2 and hasattr(st.session_state.model, "predict_proba"):
            st.subheader("ROC Curve")
            
            try:
                y_prob = st.session_state.model.predict_proba(st.session_state.X_test)[:, 1]
                fpr, tpr, _ = roc_curve(st.session_state.y_test, y_prob)
                roc_auc = auc(fpr, tpr)
                
                fig = go.Figure()
                fig.add_trace(go.Scatter(
                    x=fpr, y=tpr,
                    mode='lines',
                    name=f'ROC Curve (area = {roc_auc:.4f})'
                ))
                
                fig.add_trace(go.Scatter(
                    x=[0, 1], y=[0, 1],
                    mode='lines',
                    line=dict(dash='dash', color='gray'),
                    name='Random Classifier'
                ))
                
                fig.update_layout(
                    title="Receiver Operating Characteristic (ROC) Curve",
                    xaxis_title="False Positive Rate",
                    yaxis_title="True Positive Rate",
                    xaxis=dict(range=[0, 1]),
                    yaxis=dict(range=[0, 1]),
                    width=700,
                    height=500,
                )
                
                st.plotly_chart(fig)
                
                # Precision-Recall Curve
                st.subheader("Precision-Recall Curve")
                
                precision, recall, _ = precision_recall_curve(st.session_state.y_test, y_prob)
                pr_auc = auc(recall, precision)
                
                fig = go.Figure()
                fig.add_trace(go.Scatter(
                    x=recall, y=precision,
                    mode='lines',
                    name=f'PR Curve (area = {pr_auc:.4f})'
                ))
                
                fig.update_layout(
                    title="Precision-Recall Curve",
                    xaxis_title="Recall",
                    yaxis_title="Precision",
                    xaxis=dict(range=[0, 1]),
                    yaxis=dict(range=[0, 1]),
                    width=700,
                    height=500,
                )
                
                st.plotly_chart(fig)
            
            except Exception as e:
                st.warning(f"Could not generate ROC and PR curves: {e}")
    
    def _render_regression_evaluation(self):
        """Render regression-specific evaluation visualizations."""
        # Get predictions
        y_pred = st.session_state.model.predict(st.session_state.X_test)
        
        # Actual vs Predicted plot
        st.subheader("Actual vs Predicted Values")
        
        fig = go.Figure()
        
        # Scatter plot of actual vs predicted
        fig.add_trace(go.Scatter(
            x=st.session_state.y_test,
            y=y_pred,
            mode='markers',
            marker=dict(
                color='blue',
                opacity=0.6,
                size=8
            ),
            name='Predictions'
        ))
        
        # Perfect prediction line
        min_val = min(min(st.session_state.y_test), min(y_pred))
        max_val = max(max(st.session_state.y_test), max(y_pred))
        
        fig.add_trace(go.Scatter(
            x=[min_val, max_val],
            y=[min_val, max_val],
            mode='lines',
            line=dict(color='red', dash='dash'),
            name='Perfect Prediction'
        ))
        
        fig.update_layout(
            title="Actual vs Predicted Values",
            xaxis_title="Actual Values",
            yaxis_title="Predicted Values",
            width=700,
            height=500
        )
        
        st.plotly_chart(fig)
        
        # Residuals plot
        st.subheader("Residuals Analysis")
        
        residuals = st.session_state.y_test - y_pred
        
        # Residuals vs Predicted
        fig1 = go.Figure()
        
        fig1.add_trace(go.Scatter(
            x=y_pred,
            y=residuals,
            mode='markers',
            marker=dict(
                color='green',
                opacity=0.6,
                size=8
            ),
            name='Residuals'
        ))
        
        # Add horizontal line at y=0
        fig1.add_shape(
            type="line",
            x0=min(y_pred),
            y0=0,
            x1=max(y_pred),
            y1=0,
            line=dict(
                color="red",
                width=2,
                dash="dash",
            )
        )
        
        fig1.update_layout(
            title="Residuals vs Predicted Values",
            xaxis_title="Predicted Values",
            yaxis_title="Residuals",
            width=700,
            height=500
        )
        
        # Residuals distribution
        fig2 = px.histogram(
            residuals,
            nbins=30,
            title="Residuals Distribution",
            labels={'value': 'Residual', 'count': 'Frequency'},
        )
        
        fig2.update_layout(
            width=700,
            height=400
        )
        
        # Display plots
        cols = st.columns(2)
        with cols[0]:
            st.plotly_chart(fig1)
        with cols[1]:
            st.plotly_chart(fig2)
