import streamlit as st
import pandas as pd
import numpy as np
import os
import time
from datetime import datetime

from data_processor import DataProcessor
from model_trainer import ModelTrainer
from model_evaluator import ModelEvaluator
from model_deployer import ModelDeployer
from model_monitor import ModelMonitor
from utils import create_directories, load_deployed_models, get_model_metadata

# Create necessary directories
create_directories()

# Set page config
st.set_page_config(
    page_title="MLOps Platform",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize session state variables
if 'data' not in st.session_state:
    st.session_state.data = None
if 'processed_data' not in st.session_state:
    st.session_state.processed_data = None
if 'X_train' not in st.session_state:
    st.session_state.X_train = None
if 'X_test' not in st.session_state:
    st.session_state.X_test = None
if 'y_train' not in st.session_state:
    st.session_state.y_train = None
if 'y_test' not in st.session_state:
    st.session_state.y_test = None
if 'target_column' not in st.session_state:
    st.session_state.target_column = None
if 'model' not in st.session_state:
    st.session_state.model = None
if 'metrics' not in st.session_state:
    st.session_state.metrics = None
if 'preprocessing_pipeline' not in st.session_state:
    st.session_state.preprocessing_pipeline = None
if 'feature_names' not in st.session_state:
    st.session_state.feature_names = None
if 'deployed_models' not in st.session_state:
    st.session_state.deployed_models = load_deployed_models()
if 'selected_deployed_model' not in st.session_state:
    st.session_state.selected_deployed_model = None
if 'predictions' not in st.session_state:
    st.session_state.predictions = None
if 'prediction_history' not in st.session_state:
    st.session_state.prediction_history = {}

# Main title
st.title("End-to-End MLOps Platform")
st.markdown("---")

# Function to display data information
def display_data_info(data):
    # Display data preview
    st.subheader("Data Preview")
    st.dataframe(data.head())
    
    # Display basic info
    st.subheader("Data Information")
    
    col1, col2 = st.columns(2)
    with col1:
        st.metric("Number of Rows", data.shape[0])
        st.metric("Number of Columns", data.shape[1])
        
    with col2:
        st.metric("Missing Values", data.isna().sum().sum())
        st.metric("Duplicate Rows", data.duplicated().sum())
        
    # Data statistics
    st.subheader("Data Statistics")
    st.dataframe(data.describe())
    
    # Data types
    st.subheader("Data Types")
    dtypes_df = pd.DataFrame(data.dtypes, columns=["Data Type"])
    dtypes_df = dtypes_df.reset_index().rename(columns={"index": "Column"})
    st.dataframe(dtypes_df)

# Create tabs for each stage of the ML pipeline
tabs = st.tabs([
    "📊 Data Ingestion", 
    "🔄 Data Preprocessing", 
    "🧠 Model Training", 
    "📈 Model Evaluation", 
    "🚀 Model Deployment", 
    "📡 Model Monitoring"
])

# Data Ingestion Tab
with tabs[0]:
    st.header("Data Ingestion")
    
    # Data Source Selection
    data_source = st.radio(
        "Select Data Source", 
        options=["Upload CSV File", "Champions League Dataset (1955-2023)"],
        horizontal=True
    )
    
    if data_source == "Upload CSV File":
        # File uploader
        uploaded_file = st.file_uploader("Upload a CSV file", type="csv")
        
        if uploaded_file is not None:
            try:
                data = pd.read_csv(uploaded_file)
                st.session_state.data = data
                st.success(f"Data loaded successfully. Shape: {data.shape}")
                
                # Display data preview and info
                display_data_info(data)
                
            except Exception as e:
                st.error(f"Error loading data: {e}")
    
    else:  # Champions League Dataset
        try:
            st.info("Loading Champions League dataset (1955-2023)...")
            
            with st.spinner("Downloading dataset from Kaggle..."):
                import kagglehub
                import os
                import glob
                
                # Download dataset
                path = kagglehub.dataset_download("fardifaalam170041060/champions-league-dataset-1955-2023")
                
                # Display available files
                available_files = glob.glob(f"{path}/*.csv")
                file_names = [os.path.basename(file) for file in available_files]
                
                if file_names:
                    selected_file = st.selectbox("Select a file to load", file_names)
                    selected_path = os.path.join(path, selected_file)
                    
                    # Load selected file
                    if st.button("Load Selected File"):
                        data = pd.read_csv(selected_path)
                        st.session_state.data = data
                        st.success(f"Champions League data loaded successfully. Shape: {data.shape}")
                        
                        # Display data preview and info
                        display_data_info(data)
                else:
                    st.error("No CSV files found in the dataset.")
        
        except Exception as e:
            st.error(f"Error loading Champions League dataset: {e}")

# Data Preprocessing Tab
with tabs[1]:
    data_processor = DataProcessor()
    data_processor.render()

# Model Training Tab
with tabs[2]:
    model_trainer = ModelTrainer()
    model_trainer.render()

# Model Evaluation Tab
with tabs[3]:
    model_evaluator = ModelEvaluator()
    model_evaluator.render()

# Model Deployment Tab
with tabs[4]:
    model_deployer = ModelDeployer()
    model_deployer.render()

# Model Monitoring Tab
with tabs[5]:
    model_monitor = ModelMonitor()
    model_monitor.render()

# Footer
st.markdown("---")
st.markdown("*End-to-End MLOps Platform. Created with Streamlit.*")
